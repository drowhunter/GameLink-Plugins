rF2 Shared Memory Tools by The Iron Wolf

Version 3.7.15.0 - 2023/03/09

Copy rFactor2SharedMemoryMapPlugin64.dll to [rF2]\Bin64\Plugins\ folder.

Use included Monitor application to observe some of the exposed values while game is running and its source code as a reference on how to access exposed data.

If you notice an issue, please report at thecrewchief.org
Source code, usage sample and instructions is located at: https://github.com/TheIronWolfModding/rF2SharedMemoryMapPlugin

Have fun! :)
